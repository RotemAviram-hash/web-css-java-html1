const beginner= [];
const advanced = [];
const expert = [];
const level = [beginner,advanced,expert];


const quizScreen = document.getElementById("quizScreen");
const questions_amount = 5;
const sendBtn = document.getElementById("sendBtn");
const exitMsgBtn = document.getElementById("exitMsgBtn");
const nextLevel = document.getElementById("nextLevel");

let autoLevel = false;
const toggle = document.getElementById("autoLevelToggle");
let succeed = false



creat_Beginner(questions_amount);
creat_Advanced(questions_amount);
creat_Expert(questions_amount);
console.log("all levels")



calculatingGame()

function calculatingGame()
{
    showMsg("✖️➕משחק למידת מתמטיקה➖➗")
    let counter = 0;
    setLevel(level[counter]);
    console.log(level[counter])
    nextLevel.addEventListener("click", ()=>{

        console.log(level[counter])
        cleanScreen(); 
        counter = (counter + 1 ) % level.length;
        console.log(level)
        setLevel(level[counter]);
        nextLevel.disabled = true;
        printLevel(counter)
    })
    
}


function printLevel (counter){
    const switchSideText = document.getElementById("switchSideText")
        switch (counter) {
            case 0:
                switchSideText.textContent = "👶רמת המשחק היא: מתחילים"
                break;
            case 1:
                switchSideText.textContent = "🎓רמת המשחק היא: מתקדמים"
                break;
            case 2:
                switchSideText.textContent = "🧙‍♂️רמת המשחק היא: מומחים"
                break;

            default:
                break;
        }
        

}



function setLevel (_level)
{
    
    _level.forEach(question => {
    printQuestion(question);
    });
    checkInput(_level);
    return 
}


//FUNC WITH LISENERS
function printQuestion(_question) {
    
    const questionDiv = document.createElement("div");
    questionDiv.classList.add("questionDiv");

    const questionText = document.createElement("p");
    questionText.textContent= _question.equation;

    const answerInput = document.createElement("input");
    answerInput.type = "number";
    answerInput.addEventListener("input",()=>{
        _question.input = Number(answerInput.value);
    })

    
    
    
    questionDiv.appendChild(questionText);
    questionDiv.appendChild(answerInput);
    quizScreen.appendChild(questionDiv);
    
}

function checkInput (_level){
    let counter = 0;

    sendBtn.addEventListener("click",()=>{
        counter = 0;
        _level.forEach(question =>{
            console.log(question.answer)
            if( Math.abs(question.input - question.answer) < 0.01)
                {counter++;}
        })
        showMsg(`ענית על ${counter} שאלות נכון!
            הציון שלך הוא ${counter/questions_amount*100}`);
            
            nextLevel.disabled = false;   
        })
    
}

exitMsgBtn.addEventListener("click",()=>{
  hideMessage();
})





// Beginner //
function creat_Beginner(times)
{
    const max = 100;
    const min = 1;
    for (let i =0; i<times ; i ++)
    {
        const num1 = getRandomInt(min,max)
        const num2 = getRandomInt(min,num1)
        const operators = ['+','-'];
        const operator = operators[getRandomInt(0,operators.length-1)];

        addQuestion_Beginner(num1,num2,operator);
    
    }
    
}

function addQuestion_Beginner(num1,num2,operator){
    const question = {
        equation : addEquation_Beginner(num1,num2,operator),
        answer : addAnswer_Beginner(num1,num2,operator),
        id : "",
        input : 0

    };  
    beginner.push(question);

}

function addEquation_Beginner (num1,num2,operator) {
    return `${num1} ${operator} ${num2} =` ;
}

function addAnswer_Beginner(num1,num2,operator) {
    return eval(`${num1} ${operator} ${num2}`);
}

// Advanced //
function creat_Advanced(times){
    const max = 10;
    const min = 1;
     for (let i =0; i<times ; i ++)
    {
        const num1 = getRandomInt(min,max)
        const num2 = getRandomInt(min,num1)
        const num3 = getRandomInt(min,num2)
        const operators = ['+','-','*','/'];
        const operator1 = operators[getRandomInt(0,operators.length-1)];
        const operator2 = operators[getRandomInt(0,operators.length-1)];
        addQuestion_Advanced(num1,num2,num3,operator1,operator2);
    }
}

function addQuestion_Advanced(num1,num2,num3,operator1,operator2){
    const question = {
        equation : addEquation_Advanced(num1,num2,num3,operator1,operator2),
        answer : addAnswer_Advanced(num1,num2,num3,operator1,operator2),
        id : "",
        input : 0
    };  
    advanced.push(question);
}

function addEquation_Advanced (num1,num2,num3,operator1,operator2) {
    return `${num1} ${operator1} ${num2} ${operator2} ${num3} =` ;
}

function addAnswer_Advanced(num1,num2,num3,operator1,operator2) {
    return eval(`${num1} ${operator1} ${num2} ${operator2} ${num3} `);
}
// Expert //
function creat_Expert(times){
    const max = 50;
    const min = 1;
    for (let i =0; i<times ; i ++)
    {
        const num1 = getRandomInt(min,max)
        const num2 = getRandomInt(min,max)
        const num3 = getRandomInt(min,max)
        const operators = ['+','-','*','/'];
        const operator1 = operators[getRandomInt(0,operators.length-1)];
        const operator2 = operators[getRandomInt(0,operators.length-1)];
        addQuestion_Expert(num1,num2,num3,operator1,operator2);
    }
}

function addQuestion_Expert(num1,num2,num3,operator1,operator2){
    const question = {
        equation : addEquation_Expert(num1,num2,num3,operator1,operator2),
        answer : addAnswer_Expert(num1,num2,num3,operator1,operator2),
        id : "",
        input : 0
    };  
    expert.push(question);
}

function addEquation_Expert (num1,num2,num3,operator1,operator2) {
    return `${num1} ${operator1} (${num2} ${operator2} ${num3}) =` ;
}

function addAnswer_Expert(num1,num2,num3,operator1,operator2) {
    return eval(`${num1} ${operator1} (${num2} ${operator2} ${num3}) `);
}


// helper func

function getRandomInt(min, max) {
    // מחזיר מספר שלם בין min ל־max כולל
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function showMsg(text)
{
  
  const div = document.getElementById("divMsg");
  const p = document.getElementById("msg");
  
  p.textContent = text;
  div.classList.remove("hidden");
}

function hideMessage() {
  const div = document.getElementById("divMsg");
  div.classList.add("hidden"); // מסתיר
}

function cleanScreen() {
    quizScreen.innerHTML = "";
    beginner.length = 0;
    advanced.length = 0;
    expert.length = 0;
}

function cleanArr (arr)
{
    
}