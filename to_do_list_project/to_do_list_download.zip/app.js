let tasks = [];
const addButton = document.getElementById("addButton")

addButton.addEventListener("click", () => {
  const input = document.getElementById("taskInput");

  addNewTask(input.value);

  input.value = "";

  printTasks();
})


function printTasks() {
  const tasksList = document.getElementById("tasksList");
  tasksList.innerHTML = "";
  tasks.forEach((task) => {
    const li = document.createElement("li");
    const div = document.createElement("div");
    const p = document.createElement("p");
    const deleteButton = document.createElement("button");
    const finishButton = document.createElement("input");

    // קלאסים ל-CSS
    div.classList.add("task-row");
    p.classList.add("task-text");
    deleteButton.classList.add("delete");
    finishButton.classList.add("task-checkbox");

    // הגדרות כפתורים
    deleteButton.innerText = "DELETE";
    finishButton.type = 'checkbox';
    finishButton.checked = task.done;
    if(task.done) p.classList.add("done");
    p.innerText = task.text;

    // הכנסת אלמנטים ל-div ו-li
    div.appendChild(p);
    div.appendChild(deleteButton);
    div.appendChild(finishButton);
    li.appendChild(div);
    tasksList.appendChild(li);

    // אירועי checkbox
    finishButton.addEventListener("change", () => {
      p.classList.toggle('done');
      task.done = finishButton.checked;
    });

    // אירוע מחיקה
    deleteButton.addEventListener("click", () => {
      deleteTask(task.id);
      tasksList.removeChild(li);
    });

    // אירוע עריכה inline
    p.addEventListener("click", () => {
      const inputEdit = document.createElement("input");
      inputEdit.type = "text";
      inputEdit.value = task.text;
      inputEdit.style.flex = "1";

      div.replaceChild(inputEdit, p);
      inputEdit.focus();

      inputEdit.addEventListener("blur", () => {
        if (inputEdit.value.trim() !== "") {
          task.text = inputEdit.value;
          p.innerText = task.text;
        }
        div.replaceChild(p, inputEdit);
      });

      inputEdit.addEventListener("keydown", (e) => {
        if (e.key === "Enter") inputEdit.blur();
    });
  });
});
}

function addNewTask(taskName) {
  if (taskName == ""){return;}
  tasks.push({
    id: crypto.randomUUID(),
    text: taskName,
    done: false,
  });
}

function deleteTask(taskId) {
  tasks = tasks.filter((task) => task.id !== taskId);
}

function editTask(taskId) {

  const taskToEdit = tasks.find((t) => t.id === taskId);

  deleteTask(taskId);

  const input = document.getElementById("taskInput");

  input.value = taskToEdit.task;

}

function doneTask(taskId){

}



