const bordCells = Array.from(document.getElementsByClassName("cell"))
let turn = "X";
const bord = ["","","","","","","","",""]
const clearBtn = document.getElementById("clearBtn")
const WIN_OPTIONS = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]]
const exitGameMsgBtn = document.getElementById("exitGameMsgBtn");



bordCells.forEach((btn, index) => {//for all the cells add lisener
  btn.addEventListener("click", () => {
    makeMove(btn,index);
    isWin()
    isEven()    
  });
});

clearBtn.addEventListener("click",()=>{
  clearBord();
})

exitGameMsgBtn.addEventListener("click",()=>{
  hideMessage();
})

//פעולות לחצנים

function makeMove(button,index) {
  bord[index] = turn;
  if (button.innerText) return;
  button.innerText = turn ;
  turn = turn == "X" ? "O" : "X";
}

function clearBord ()
{
  bordCells.forEach(cell =>{cell.innerText = "";});
 for (let i = 0; i < bord.length; i++) {bord[i] = "";}
}



//בדיקת סטטוס המשחק 

function claulateWINS()
{
  
  for (let i = 0 ; i < WIN_OPTIONS.length ; i++)//8
  {
    let a = bord[WIN_OPTIONS[i][0]];
    let b = bord[WIN_OPTIONS[i][1]];
    let c = bord[WIN_OPTIONS[i][2]];

    if (a === b && b === c && a !== "") {
      return true;
    }
  }
  return false;
}

function isWin()
{
  const player = turn == "X" ? "O" : "X"
  if (claulateWINS())
  {
    showMsg(`🎉the ${player}  player won!🎉`);
    
  }
  
}

function isEven()//הנחה שאם המסך מלא סימן שאף אחד לא ניצח 
{
  for (let i = 0; i < bord.length; i++) 
  {
    if(bord[i] === "")
      return false;
  }
  showMsg("🤝It's a tie !!🤝")

}

// הודעה שקופצת 

function showMsg(text)
{
  clearBord();
  const div = document.getElementById("gameMessage");
  const p = document.getElementById("gameMsg");
  
  
  p.textContent = text;
  div.classList.remove("hidden");
}

  
function hideMessage() {
  const div = document.getElementById("gameMessage");
  div.classList.add("hidden"); // מסתיר
}